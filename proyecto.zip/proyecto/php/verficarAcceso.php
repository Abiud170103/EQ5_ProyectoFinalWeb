
<?php
    session_start();
    $resultado = 1;

    if($resultado == 1){

        $_SESSION["pass"] = $_POST["pass"];
        $_SESSION["user"] = $_POST["user"];
        $_SESSION['loggedin'] = true;
        header("location: admin.php");
    }else{
        header("location: ../admin.html");
    }



?>
