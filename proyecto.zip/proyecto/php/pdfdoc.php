<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require('../fpdf186/fpdf.php');

// Datos del formulario
$bol = $_POST['boleta'];
$con = $_POST['contrasena'];

$conexion = new mysqli('localhost', 'root', '', 'tutorias');
$conexion->set_charset("utf8");

if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}

$sql = "
    SELECT 
        Alumnos.boleta,
        Alumnos.nombre AS nombre_alumno,
        Alumnos.primer_apellido,
        Alumnos.segundo_apellido,
        Alumnos.fecha_nacimiento,
        Alumnos.telefono,
        Alumnos.semestre,
        Alumnos.carrera,
        Alumnos.email,
        Alumnos.tipo_tutoria,
        Alumnos.maestro_id,
        Maestros.nombre AS nombre_maestro
    FROM 
        Alumnos
    JOIN 
        Maestros ON Alumnos.maestro_id = Maestros.id
    WHERE 
        Alumnos.boleta = ? AND
        Alumnos.contrasena = ?
";

$consulta = $conexion->prepare($sql);
if (!$consulta) {
    die("Error en la preparación de la consulta: " . $conexion->error);
}

$consulta->bind_param("ss", $bol, $con);
$consulta->execute();
$res = $consulta->get_result();

class PDF extends FPDF {
    function header() {
        $this->SetLineWidth(1);
        $this->SetDrawColor(0, 102, 153);
        $this->Line(10, 10, $this->GetPageWidth() - 10, 10);

        $this->Image('../imgs/IPN.png', 10, 25, 38);
        $pageWidth = $this->GetPageWidth();
        $posX = $pageWidth - 42 - 1;
        $this->Image('../imgs/escudoESCOM.png', $posX, 35, 30);
        $this->SetFont('Arial', 'B', 18);
        $this->Cell(0, 60, iconv('UTF-8', 'windows-1252', 'PROGRAMA DE TUTORÍAS'), 0, 1, 'C');
        $this->Ln(10);
    }

    function footer() {
        $this->SetY(-20);
        $this->SetFont('Arial', 'B', 10);
        $this->Cell(0, 10, 'Pagina ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
    }
}

if ($res->num_rows == 1) {
    $pdf = new PDF();
    $pdf->AliasNbPages();
    $pdf->AddPage();
    
    $pdf->SetFont('Arial','',14);
    
    $fila = $res->fetch_assoc();

    $pdf->Cell(0, 10, iconv('UTF-8', 'windows-1252', 'Boleta: ' . $fila['boleta']), 0, 1);
    $pdf->Ln(); 
    $pdf->Cell(0, 10, iconv('UTF-8', 'windows-1252', 'Nombre: ' . $fila['nombre_alumno']), 0, 1);
    $pdf->Ln();
    $pdf->Cell(0, 10, iconv('UTF-8', 'windows-1252', 'Apellidos: ' . $fila['primer_apellido'] . ' ' . $fila['segundo_apellido']), 0, 1);
    $pdf->Ln(); 
    $pdf->Cell(0, 10, iconv('UTF-8', 'windows-1252', 'Fecha de nacimiento: ' . $fila['fecha_nacimiento']), 0, 1);
    $pdf->Ln(); 
    $pdf->Cell(0, 10, iconv('UTF-8', 'windows-1252', 'Teléfono: ' . $fila['telefono']), 0, 1);
    $pdf->Ln();   
    $pdf->Cell(0, 10, iconv('UTF-8', 'windows-1252', 'Semestre: ' . $fila['semestre']), 0, 1);
    $pdf->Ln();
    $pdf->Cell(0, 10, iconv('UTF-8', 'windows-1252', 'Carrera: ' . $fila['carrera']), 0, 1);
    $pdf->Ln(); 
    $pdf->SetFont('Arial', 'B', 14);
    $pdf->Cell(0, 10, iconv('UTF-8', 'windows-1252', 'Tutor asignado: ' . $fila['nombre_maestro']), 0, 1);
    $pdf->Ln(); 
    $pdf->SetFont('Arial', '', 14);
    $pdf->Cell(0, 10, iconv('UTF-8', 'windows-1252', 'Tipo de tutoría: ' . $fila['tipo_tutoria']), 0, 1);

    $pdf->Output('I', $bol . '.pdf');
} else {
    echo '<script>alert("Número de boleta, usuario o contraseña incorrectos. Por favor, verifica tus datos."); window.location.href = "../intropdf.html";</script>';
}

mysqli_close($conexion);
?>
