<?php
    session_start();
    $dato = $_REQUEST["nombreSesion"];
    session_destroy();
    header("location: ../admin.html");
?>