function mostrar() {
    var preferencia = document.getElementById('preferenciaTutor').value;

    var xhr = new XMLHttpRequest();
    xhr.open('GET', 'obt.php?preferenciaTutor=' + preferencia, true);
    xhr.onload = function() {
        if (this.status === 200) {
            var maestros = JSON.parse(this.responseText);
            var selectMaestro = document.getElementById('maestro');

            // Limpiar el select de maestros
            selectMaestro.innerHTML = '';

            // Agregar los maestros obtenidos al select
            maestros.forEach(function(maestro) {
                var option = document.createElement('option');
                option.value = maestro.nombre;  // Asegúrate de que `nombre` sea el valor correcto para `option.value`
                option.text = maestro.nombre;
                selectMaestro.appendChild(option);
            });
        }
    };
    xhr.send();
}
function limpiarFormulario() {
    document.getElementById('formularioRegistro').reset();
}