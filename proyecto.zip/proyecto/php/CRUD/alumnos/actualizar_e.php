<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: ../../admin.php');
    exit;
}

$conn = new mysqli('localhost', 'root', '', 'tutorias');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$boleta = $_POST['boleta'];

if ($boleta) {
    $sql = "SELECT * FROM Alumnos WHERE boleta=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $boleta);
    $stmt->execute();
    $result = $stmt->get_result();
    $alumno = $result->fetch_assoc();
    $stmt->close();
} else {
    header("Location: ../admin.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $alumno['nombre'];
    $primerApe = $alumno['primer_apellido'];
    $segundoApe = $alumno['segundo_apellido'];
    $fechaNac = $alumno['fecha_nacimiento'];
    $telefono = $alumno['telefono'];
    $semestre = $alumno['semestre'];
    $carrera = $alumno['carrera'];
    $email = $alumno['email'];
    $tutoriaInteres = $alumno['tipo_tutoria'];
    $idmaestro = $alumno['maestro_id'];
}
?>

<!DOCTYPE html>
<html lang='es'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet' integrity='sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH' crossorigin='anonymous'>
    <link rel='stylesheet' href='../../../css/style.css'>
    <title>Actualizar Estudiante</title>
</head>
<body>
    <div class='contenedor'>
        <nav class='navbar navbar-expand-lg bg-body-tertiary'>
            <div class='container-fluid'>
                <a class='navbar-brand' href='#'><img src='../../../imgs/IPN.png' alt='Logo IPN' width='90' height='104' class='d-inline-block align-text-top'></a>
                <button class='navbar-toggler' type='button' data-bs-toggle='collapse' data-bs-target='#navbarSupportedContent' aria-controls='navbarSupportedContent' aria-expanded='false' aria-label='Toggle navigation'>
                    <span class='navbar-toggler-icon'></span>
                </button>
                <a class='navbar-brand' href='#'><img src='../../../imgs/escudoESCOM.png' alt='Logo escom' width='100' height='90' class='d-inline-block align-text-top'></a>
                <div class='collapse navbar-collapse' id='navbarSupportedContent'>
                    <ul class='navbar-nav me-auto mb-2 mb-lg-0'>
                        <li class='nav-item'><a class='nav-link active' aria-current='page' href='../../../inicio.html'>Inicio</a></li>
                        <li class='nav-item dropdown'>
                            <a class='nav-link dropdown-toggle' href='#' role='button' data-bs-toggle='dropdown' aria-expanded='false'>Registro</a>
                            <ul class='dropdown-menu'>
                                <li><a class='dropdown-item' href='../../../registro.html'>Ir a Registro</a></li>
                                <li><a class='dropdown-item' href='../../../intropdf.html'>Generar PDF</a></li>
                            </ul>
                        </li>
                        <li class='nav-item'><a class='nav-link active' aria-current='page' href='../../../admin.html'>Admin</a></li>
                        <li class='nav-item dropdown'>
                            <a class='nav-link dropdown-toggle' href='#' role='button' data-bs-toggle='dropdown' aria-expanded='false'>Cuentas Oficiales</a>
                            <ul class='dropdown-menu'>
                                <li><a class='dropdown-item' href='https://www.ipn.mx' target='_blank'>Página web</a></li>
                                <li><a class='dropdown-item' href='https://www.facebook.com/escomipnmx/' target='_blank'>Facebook</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class='formulario'>
            <h2>Actualizar registro del alumno</h2><br>
            <form action='act_e.php?action=update' method='POST' id='formularioRegistro'>
                <fieldset><br>
                    <legend>Datos personales y académicos</legend>
                    <label for='boleta'>Boleta:</label>
                    <input type='text' id='boleta' name='boleta' value='<?= htmlspecialchars($alumno['boleta']); ?>' readonly>
                    
                    <label for='nombre'>Nombre:</label>
                    <input type='text' id='nombre' name='nombre' value='<?= htmlspecialchars($alumno['nombre']); ?>' required>
                    
                    <label for='primerApe'>Primer Apellido:</label>
                    <input type='text' id='primerApe' name='primerApe' value='<?= htmlspecialchars($alumno['primer_apellido']); ?>' required>
                    
                    <label for='segundoApe'>Segundo Apellido:</label>
                    <input type='text' id='segundoApe' name='segundoApe' value='<?= htmlspecialchars($alumno['segundo_apellido']); ?>' required>

                    <label for='fechaNac'>Fecha de Nacimiento:</label>
                    <input type='date' id='fechaNac' name='fechaNac' value='<?= htmlspecialchars($alumno['fecha_nacimiento']); ?>' required>
                    
                    <label for='telefono'>Teléfono:</label>
                    <input type='tel' id='telefono' name='telefono' value='<?= htmlspecialchars($alumno['telefono']); ?>'>
                    
                    <label for='semestre'>Semestre:</label>
                    <select id='semestre' name='semestre' required>
                        <option value='' disabled>Selecciona tu semestre</option>
                        <option value='1' <?= $alumno['semestre'] == 1 ? 'selected' : '' ?>>Primero</option>
                        <option value='2' <?= $alumno['semestre'] == 2 ? 'selected' : '' ?>>Segundo</option>
                        <option value='3' <?= $alumno['semestre'] == 3 ? 'selected' : '' ?>>Tercero</option>
                        <option value='4' <?= $alumno['semestre'] == 4 ? 'selected' : '' ?>>Cuarto</option>
                        <option value='5' <?= $alumno['semestre'] == 5 ? 'selected' : '' ?>>Quinto</option>
                        <option value='6' <?= $alumno['semestre'] == 6 ? 'selected' : '' ?>>Sexto</option>
                        <option value='7' <?= $alumno['semestre'] == 7 ? 'selected' : '' ?>>Séptimo</option>
                        <option value='8' <?= $alumno['semestre'] == 8 ? 'selected' : '' ?>>Octavo</option>
                        <option value='9' <?= $alumno['semestre'] == 9 ? 'selected' : '' ?>>Noveno</option>
                        <option value='10' <?= $alumno['semestre'] == 10 ? 'selected' : '' ?>>Décimo</option>
                    </select>
                    
                    <label for='carrera'>Carrera:</label>
                    <select id='carreraSelec' name='carreraSelec' required>
                        <option value='' disabled>Selecciona una opción</option>
                        <option value='ISC' <?= $alumno['carrera'] == 'ISC' ? 'selected' : '' ?>>Ingeniería en Sistemas Computacionales</option>
                        <option value='IIA' <?= $alumno['carrera'] == 'IIA' ? 'selected' : '' ?>>Ingeniería en Inteligencia Artificial</option>
                        <option value='LCD' <?= $alumno['carrera'] == 'LCD' ? 'selected' : '' ?>>Licenciatura en Ciencia de Datos</option>
                    </select>
                    
                    <label for='preferenciaTutor'>¿Prefieres que tu tutor sea hombre o mujer?:</label>
                    <select id='preferenciaTutor' name='preferenciaTutor' onchange='mostrar()' required>
                        <option value='' disabled selected>Selecciona una opción</option>
                        <option value='hombre'>Hombre</option>
                        <option value='mujer'>Mujer</option>
                        <option value='indistinto'>Indistinto</option>
                    </select>

                    <label for='maestro'>Maestr@:</label>
                    <select id='maestro' name='maestro'>
                        <!-- The options will be loaded by the mostrar() function -->
                    </select>

                    <label for='tutoriaInteres'>Tutoría de Interés:</label>
                    <select id='tutoriaInteres' name='tutoriaInteres' required>
                        <option value='' disabled>Selecciona una opción</option>
                        <option value='Individual' <?= $alumno['tipo_tutoria'] == 'Individual' ? 'selected' : '' ?>>Individual</option>
                        <option value='Grupal' <?= $alumno['tipo_tutoria'] == 'Grupal' ? 'selected' : '' ?>>Grupal</option>
                        <option value='Recuperación Académica' <?= $alumno['tipo_tutoria'] == 'Recuperación Académica' ? 'selected' : '' ?>>Recuperación Académica</option>
                        <option value='Regularización' <?= $alumno['tipo_tutoria'] == 'Regularización' ? 'selected' : '' ?>>Regularización</option>
                        <option value='Entre Pares' <?= $alumno['tipo_tutoria'] == 'Entre Pares' ? 'selected' : '' ?>>Entre Pares</option>
                    </select>
                </fieldset>

                <fieldset>
                    <legend>Cuenta</legend>
                    <label for='email'>Correo Electrónico Institucional:</label>
                    <input type='email' id='email' name='email' value='<?= htmlspecialchars($alumno['email']) ?>' required>
                    
                    <label for='contrasena'>Nueva Contraseña (dejar en blanco para no cambiar)</label>
                    <input type='password' id='contrasena' name='contrasena'>
                </fieldset>

                <div class='botones'>
                    <input type='submit' value='Actualizar'>
                </div>
            </form>
        </div>
    </div>
    <script src='val.js'></script>
    <script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js' integrity='sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz' crossorigin='anonymous'></script>
</body>
</html>
