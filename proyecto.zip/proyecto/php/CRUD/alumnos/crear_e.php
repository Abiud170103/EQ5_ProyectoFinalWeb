<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: ../../login.php');
    exit;
}
// Habilitar el reporte de errores
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Conexión a la base de datos
$conexion = new mysqli('localhost', 'root', '', 'tutorias');
if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}

// Obtener los datos del formulario
$boleta = $_POST['boleta'];
$nombre = $_POST['nombre'];
$primerApe = $_POST['primerApe'];
$segundoApe = $_POST['segundoApe'];
$fechaNac = $_POST['fechaNac'];
$telefono = $_POST['telefono'];
$semestre = $_POST['semestre'];
$carrera = $_POST['carreraSelec'];
$preferenciaTutor = $_POST['preferenciaTutor'];
$maestro = $_POST['maestro'];
$tutoriaInteres = $_POST['tutoriaInteres'];
$email = $_POST['email'];
$contrasena = $_POST['contrasena'];

// Verificar que el nombre del tutor no esté vacío
if (empty($maestro)) {
    die("El nombre del tutor no puede estar vacío.");
}

// Obtener el id del maestro basado en el nombre
$sql_Maestro = "SELECT id FROM Maestros WHERE nombre = ?";
$stmt_maestro = $conexion->prepare($sql_Maestro);
if ($stmt_maestro === false) {
    die("Error en la preparación de la consulta: " . $conexion->error);
}
$stmt_maestro->bind_param("s", $maestro);
$stmt_maestro->execute();
$res1 = $stmt_maestro->get_result();

if ($res1->num_rows == 1) {
    $fila_maestro = $res1->fetch_assoc();
    $maestro_id = $fila_maestro['id'];
} else {
    die("Error al obtener el ID del maestro o el tutor no existe.");
}

// Insertar los datos del alumno
$sql_Alumno = "
    INSERT INTO Alumnos (
        boleta, nombre, primer_apellido, segundo_apellido, fecha_nacimiento, telefono, semestre, carrera, email, contrasena, tipo_tutoria, maestro_id
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
$stmt_alumno = $conexion->prepare($sql_Alumno);
if ($stmt_alumno === false) {
    die("Error en la preparación de la consulta de inserción: " . $conexion->error);
}
$stmt_alumno->bind_param("ssssssissssi", $boleta, $nombre, $primerApe, $segundoApe, $fechaNac, $telefono, $semestre, $carrera, $email, $contrasena, $tutoriaInteres, $maestro_id);

if ($boleta != '' && $stmt_alumno->execute()) {

    echo "<html lang='es'>
        <head>
            <meta charset='UTF-8'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
            <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet' integrity='sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH' crossorigin='anonymous'>
            <link rel='stylesheet' href='../../../css/style.css'>
            <title>Registro Exitoso</title>
        </head>
        <body>
            <div class='contenedor'>
                <nav class='navbar navbar-expand-lg bg-body-tertiary'>
                    <div class='container-fluid'>
                        <a class='navbar-brand' href='#'><img src='../../../imgs/IPN.png' alt='Logo IPN'  width='90' height='104' class='d-inline-block align-text-top'></a>
                        <button class='navbar-toggler' type='button' data-bs-toggle='collapse' data-bs-target='#navbarSupportedContent' aria-controls='navbarSupportedContent' aria-expanded='false' aria-label='Toggle navigation'>
                            <span class='navbar-toggler-icon'></span>
                        </button>
                        <a class='navbar-brand' href='#'><img src='../../../imgs/escudoESCOM.png' alt='Logo escom'  width='100' height='90' class='d-inline-block align-text-top'></a>
                        <div class='collapse navbar-collapse' id='navbarSupportedContent'>
                            <ul class='navbar-nav me-auto mb-2 mb-lg-0'>
                                <li class='nav-item'><a class='nav-link active' aria-current='page' href='../../../inicio.html'>Inicio</a></li>
                                <li class='nav-item dropdown'>
                                    <a class='nav-link dropdown-toggle' href='#' role='button' data-bs-toggle='dropdown' aria-expanded='false'>Registro</a>
                                    <ul class='dropdown-menu'>
                                        <li><a class='dropdown-item' href='../../../registro.html'>Ir a Registro</a></li>
                                        <li><a class='dropdown-item' href='../../../intropdf.html'>Generar PDF</a></li>
                                    </ul>
                                </li>
                                <li class='nav-item'><a class='nav-link active' aria-current='page' href='../../../admin.html'>Admin</a></li>
                                <li class='nav-item dropdown'>
                                    <a class='nav-link dropdown-toggle' href='#' role='button' data-bs-toggle='dropdown' aria-expanded='false'>Cuentas Oficiales</a>
                                    <ul class='dropdown-menu'>
                                        <li><a class='dropdown-item' href='https://www.ipn.mx' target='_blank'>Página web</a></li>
                                        <li><a class='dropdown-item' href='https://www.facebook.com/escomipnmx/' target='_blank'>Facebook</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
                <div class='formulario'>
                        <h3 style='text-align:center;'>Alumno registrado con exito.</h3>
                        <h3 style='text-align:center;'>Datos del alumno:</h3>
                        <p><strong>Boleta:</strong> $boleta</p>
                        <p><strong>Nombre:</strong> $nombre</p>
                        <p><strong>Primer Apellido:</strong> $primerApe</p>
                        <p><strong>Segundo Apellido:</strong> $segundoApe</p>
                        <p><strong>Fecha de Nacimiento:</strong> $fechaNac</p>
                        <p><strong>Teléfono:</strong> $telefono</p>
                        <p><strong>Semestre:</strong> $semestre</p>
                        <p><strong>Carrera:</strong> $carrera</p>
                        <p><strong>Preferencia de Tutor:</strong> $preferenciaTutor</p>
                        <p><strong>Maestro:</strong> $maestro</p>
                        <p><strong>Tutoría de Interés:</strong> $tutoriaInteres</p>
                        <p><strong>Email:</strong> $email</p>
                        <p><strong>Contraseña:</strong> $contrasena</p>
                </div>
                    
                
            </div>
            <script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js' integrity='sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz' crossorigin='anonymous'></script>
        </body>
    </html>";
} else {
    echo "<html lang='es'>
        <head>
            <meta charset='UTF-8'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
            <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet' integrity='sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH' crossorigin='anonymous'>
            <link rel='stylesheet' href='../../../css/style.css'>
            <title>Error en el Registro de Tutorías</title>
        </head>
        <body>
            <div class='contenedor'>
                <nav class='navbar navbar-expand-lg bg-body-tertiary'>
                <div class='container-fluid'>
                    <a class='navbar-brand' href='#'><img src='../../../imgs/IPN.png' alt='Logo IPN'  width='90' height='104' class='d-inline-block align-text-top'></a>
                    <button class='navbar-toggler' type='button' data-bs-toggle='collapse' data-bs-target='#navbarSupportedContent' aria-controls='navbarSupportedContent' aria-expanded='false' aria-label='Toggle navigation'>
                        <span class='navbar-toggler-icon'></span>
                    </button>
                    <a class='navbar-brand' href='#'><img src='../../../imgs/escudoESCOM.png' alt='Logo escom'  width='100' height='90' class='d-inline-block align-text-top'></a>
                    <div class='collapse navbar-collapse' id='navbarSupportedContent'>
                        <ul class='navbar-nav me-auto mb-2 mb-lg-0'>
                            <li class='nav-item'><a class='nav-link active' aria-current='page' href='../../../inicio.html'>Inicio</a></li>
                            <li class='nav-item dropdown'>
                                <a class='nav-link dropdown-toggle' href='#' role='button' data-bs-toggle='dropdown' aria-expanded='false'>Registro</a>
                                <ul class='dropdown-menu'>
                                    <li><a class='dropdown-item' href='../../../registro.html'>Ir a Registro</a></li>
                                    <li><a class='dropdown-item' href='../../../intropdf.html'>Generar PDF</a></li>
                                </ul>
                            </li>
                            <li class='nav-item'><a class='nav-link active' aria-current='page' href='../../../admin.html'>Admin</a></li>
                            <li class='nav-item dropdown'>
                                <a class='nav-link dropdown-toggle' href='#' role='button' data-bs-toggle='dropdown' aria-expanded='false'>Cuentas Oficiales</a>
                                <ul class='dropdown-menu'>
                                    <li><a class='dropdown-item' href='https://www.ipn.mx' target='_blank'>Página web</a></li>
                                    <li><a class='dropdown-item' href='https://www.facebook.com/escomipnmx/' target='_blank'>Facebook</a></li>
                                </ul>
                            </li>
                        </ul>
                </div>
            </div>
        </nav>
                <h3 style='text-align:center;'>Hubo un error en el registro del alumno:</h3>
                <p><strong>Nombre:</strong> $nombre</p>
            </div>
            <script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js' integrity='sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz' crossorigin='anonymous'></script>
        </body>
    </html>";
}

$conexion->close();
?>
