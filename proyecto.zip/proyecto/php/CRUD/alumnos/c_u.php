<?php 
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit;
}

?>

<!DOCTYPE html>
<html lang='es'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet' integrity='sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH' crossorigin='anonymous'>
    <link rel='stylesheet' href='../../../css/style.css'>
    <title>Crear Estudiante</title>
</head>
<body>
    <div class="contenedor">
        <nav class='navbar navbar-expand-lg bg-body-tertiary'>
            <div class='container-fluid'>
                <a class='navbar-brand' href='#'><img src='../../../imgs/IPN.png' alt='Logo IPN'  width='90' height='104' class='d-inline-block align-text-top'></a>
                <button class='navbar-toggler' type='button' data-bs-toggle='collapse' data-bs-target='#navbarSupportedContent' aria-controls='navbarSupportedContent' aria-expanded='false' aria-label='Toggle navigation'>
                    <span class='navbar-toggler-icon'></span>
                </button>
                <a class='navbar-brand' href='#'><img src='../../../imgs/escudoESCOM.png' alt='Logo escom'  width='100' height='90' class='d-inline-block align-text-top'></a>
                <div class='collapse navbar-collapse' id='navbarSupportedContent'>
                    <ul class='navbar-nav me-auto mb-2 mb-lg-0'>
                        <li class='nav-item'><a class='nav-link active' aria-current='page' href='../../../inicio.html'>Inicio</a></li>
                        <li class='nav-item dropdown'>
                            <a class='nav-link dropdown-toggle' href='#' role='button' data-bs-toggle='dropdown' aria-expanded='false'>Registro</a>
                            <ul class='dropdown-menu'>
                                <li><a class='dropdown-item' href='../../../registro.html'>Ir a Registro</a></li>
                                <li><a class='dropdown-item' href='../../../intropdf.html'>Generar PDF</a></li>
                            </ul>
                        </li>
                        <li class='nav-item'><a class='nav-link active' aria-current='page' href='../../../admin.html'>Admin</a></li>
                        <li class='nav-item dropdown'>
                            <a class='nav-link dropdown-toggle' href='#' role='button' data-bs-toggle='dropdown' aria-expanded='false'>Cuentas Oficiales</a>
                            <ul class='dropdown-menu'>
                                <li><a class='dropdown-item' href='https://www.ipn.mx' target='_blank'>Página web</a></li>
                                <li><a class='dropdown-item' href='https://www.facebook.com/escomipnmx/' target='_blank'>Facebook</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="formulario">
            <h2>Creal registro del alumno</h2><br>
            <form action="crear_e.php" method="POST" id="formularioRegistro">
                <fieldset><br>
                    <legend>Datos personales y académicos</legend>
                    <label for="boleta">Boleta:</label>
                    <input type="text" id="boleta" name="boleta" required>
                    
                    <label for="nombre">Nombre:</label>
                    <input type="text" id="nombre" name="nombre" required>
                    
                    <label for="primerApe">Primer Apellido:</label>
                    <input type="text" id="primerApe" name="primerApe" required>
                    
                    <label for="segundoApe">Segundo Apellido:</label>
                    <input type="text" id="segundoApe" name="segundoApe" required>

                    <label for="fechaNac">Fecha de Nacimiento:</label>
                    <input type="date" id="fechaNac" name="fechaNac" required>
                    
                    <label for="telefono">Teléfono:</label>
                    <input type="tel" id="telefono" name="telefono">
                    
                    <label for="semestre">Semestre:</label>
                    <select id="semestre" name="semestre" required>
                        <option value="" disabled selected>Selecciona tu semestre</option>
                        <option value="1">Primero</option>
                        <option value="2">Segundo</option>
                        <option value="3">Tercero</option>
                        <option value="4">Cuarto</option>
                        <option value="5">Quinto</option>
                        <option value="6">Sexto</option>
                        <option value="7">Séptimo</option>
                        <option value="8">Octavo</option>
                        <option value="9">Noveno</option>
                        <option value="10">Décimo</option>
                    </select>
                    
                    <label for="carrera">Carrera:</label>
                    <select id="carreraSelec" name="carreraSelec" required>
                        <option value="" disabled selected>Selecciona una opción</option>
                        <option value="ISC">Ingeniería en Sistemas Computacionales</option>
                        <option value="IIA">Ingeniería en Inteligencia Artificial</option>
                        <option value="LCD">Licenciatura en Ciencia de Datos</option>
                    </select>
                    
                    <label for="preferenciaTutor">¿Prefieres que tu tutor sea hombre o mujer?:</label>
                    <select id="preferenciaTutor" name="preferenciaTutor" onchange="mostrar()" required>
                        <option value="" disabled selected>Selecciona una opción</option>
                        <option value="hombre">Hombre</option>
                        <option value="mujer">Mujer</option>
                        <option value="indistinto">Indistinto</option>
                    </select>

                    <label for="maestro">Maestr@:</label>
                    <select id="maestro" name="maestro">
                    </select>

                    <label for="tutoriaInteres">Tutoría de Interés:</label>
                    <select id="tutoriaInteres" name="tutoriaInteres" required>
                        <option value="" disabled selected>Selecciona una opción</option>
                        <option value="Individual">Individual</option>
                        <option value="Grupal">Grupal</option>
                        <option value="Recuperación Académica">Recuperación Académica</option>
                        <option value="Regularización">Regularización</option>
                        <option value="Entre Pares">Entre Pares</option>
                    </select>
                </fieldset>

                <fieldset>
                    <legend>Cuenta</legend>
                    <label for="email">Correo Electrónico Institucional:</label>
                    <input type="email" id="email" name="email" required>
                    
                    <label for="contrasena">Contraseña:</label>
                    <input type="password" id="contrasena" name="contrasena" required>
                </fieldset>
                
                <div class="botones">
                    <input type="submit" value="Registrar">
                    <input type="button" value="Limpiar" onclick="limpiarFormulario()">
                </div>
            </form>
        </div>
    </div>
    <script src="../val.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity='sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz' crossorigin='anonymous'></script>
</body>
</html>

