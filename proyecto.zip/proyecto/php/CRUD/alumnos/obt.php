<?php
// Habilitar el reporte de errores
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tutorias";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener la preferencia de género del parámetro GET
$preferencia = isset($_GET['preferenciaTutor']) ? $_GET['preferenciaTutor'] : 'indistinto';

// Construir la consulta SQL
$sql = "SELECT m.id, m.nombre, m.genero
        FROM Maestros m
        LEFT JOIN Alumnos a ON m.id = a.maestro_id
        WHERE (m.genero = ? OR ? = 'indistinto')
        GROUP BY m.id
        HAVING COUNT(a.boleta) < 15";

// Preparar y ejecutar la consulta
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("Error en la preparación de la consulta: " . $conn->error);
}
$stmt->bind_param("ss", $preferencia, $preferencia);
$stmt->execute();
$result = $stmt->get_result();

$maestros = array();
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $maestros[] = $row;
    }
}

$conn->close();

// Devolver los datos en formato JSON
header('Content-Type: application/json');
echo json_encode($maestros);
?>
