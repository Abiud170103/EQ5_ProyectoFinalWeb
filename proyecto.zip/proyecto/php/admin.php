<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: ../admin.html');
    exit;
}

$validos = [
    'sharon' => '1234567890',
    'fernanda' => '0987654321'
];


$pass = $_SESSION['pass'];
$usr = $_SESSION['user'];

if (isset($_POST['logout'])) {
    session_destroy();
    echo "Session destroyed";
    exit();
}

if (isset($validos[$usr]) && $validos[$usr] === $pass) {
    $conn = new mysqli('localhost', 'root', '', 'tutorias');
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT * FROM Alumnos";
    $result = $conn->query($sql);
    $sql2 = "SELECT * FROM maestros";
    $result2 = $conn->query($sql2);
    
    if (!$result) {
        die("Error en la consulta de los alumnos: " . $conn->error);
    }
    if (!$result2) {
        die("Error en la consulta de los tutores: " . $conn->error);
    }

    $campos = ['boleta', 'nombre', 'primer_apellido', 'segundo_apellido', 'fecha_nacimiento', 'telefono', 'semestre', 'carrera', 'tipo_tutoria', 'maestro_id', 'email'];
    $campos2 = ['id', 'nombre', 'genero'];
?>

<!DOCTYPE html>
<html lang='es'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet' integrity='sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH' crossorigin='anonymous'>
    <link rel='stylesheet' href='../css/style.css'>
    <title>Administración</title>
</head>
<body>
    <nav class='navbar navbar-expand-lg bg-body-tertiary'>
        <div class='container-fluid'>
            <a class='navbar-brand' href='#'><img src='../imgs/IPN.png' alt='Logo IPN' width='90' height='104' class='d-inline-block align-text-top'></a>
            <button class='navbar-toggler' type='button' data-bs-toggle='collapse' data-bs-target='#navbarSupportedContent' aria-controls='navbarSupportedContent' aria-expanded='false' aria-label='Toggle navigation'><span class='navbar-toggler-icon'></span></button>
            <a class='navbar-brand' href='#'><img src='../imgs/escudoESCOM.png' alt='Logo escom' width='100' height='90' class='d-inline-block align-text-top'></a>
            <div class='collapse navbar-collapse' id='navbarSupportedContent'>
                <ul class='navbar-nav me-auto mb-2 mb-lg-0'>
                    <li class='nav-item'><a class='nav-link active' aria-current='page' href='../inicio.html'>Inicio</a></li>
                    <li class='nav-item'><a class='nav-link active' aria-current='page' href='../registro.html'>Registro</a></li>
                    <li class='nav-item'><a class='nav-link active' aria-current='page' href='../admin.html'>Admin</a></li>
                    <li class='nav-item dropdown'>
                        <a class='nav-link dropdown-toggle' href='#' role='button' data-bs-toggle='dropdown' aria-expanded='false'>Cuentas Oficiales</a>
                        <ul class='dropdown-menu'>
                            <li><a class='dropdown-item' href='https://www.ipn.mx' target='_blank'>Página web</a></li>
                            <li><a class='dropdown-item' href='https://www.facebook.com/escomipnmx/' target='_blank'>Facebook</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class='contenedor'>
        <h1 class='section-header'>Administración de Estudiantes</h1>
        <div class='section-content' id='estudiante'>
            <div class='table-responsive'>
                <table class='table table-striped'>
                    <thead>
                        <tr>
                            <?php foreach ($campos as $campo): ?>
                                <th><?= ucfirst(str_replace('_', ' ', $campo)) ?></th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <?php foreach ($campos as $campo): ?>
                                    <td><?= htmlspecialchars($row[$campo] ?? '') ?></td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div><br>
        <div class="dropdown">
            <button class="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
            Acciones
            </button> <br><br><br>
            <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="CRUD/alumnos/c_u.php">Crear alumno</a></li>
                <li><a class="dropdown-item" href="CRUD/alumnos/u_u.php">Actualizar alumno</a></li>
                <li><a class="dropdown-item" href="CRUD/alumnos/d_u.php">Borrar alumno</a></li>
            </ul>
        </div>

        <h1 class='section-header'>Administración de Tutores</h1>
        <div class='section-content' id='tutor'>
            <div class='table-responsive'>
                <table class='table table-striped'>
                    <thead>
                        <tr>
                            <?php foreach ($campos2 as $campo2): ?>
                                <th><?= ucfirst(str_replace('_', ' ', $campo2)) ?></th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>

                    <tbody>
                        <?php while ($row = $result2->fetch_assoc()): ?>
                            <tr>
                                <?php foreach ($campos2 as $campo2): ?>
                                    <td><?= htmlspecialchars($row[$campo2] ?? '') ?></td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div><br>



    </div>
    <script src="../js/validacion.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity='sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz' crossorigin='anonymous'></script>
</body>
</html>

<?php
    $conn->close();
} else {
    header("location: ../admin.html");
}
?>
