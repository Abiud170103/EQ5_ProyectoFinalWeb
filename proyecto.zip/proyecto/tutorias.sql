
-- Tabla Maestros
CREATE TABLE Maestros (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    genero VARCHAR(15) NOT NULL
);

-- Tabla Alumnos
CREATE TABLE Alumnos (
    boleta VARCHAR(20) PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    primer_apellido VARCHAR(100) NOT NULL,
    segundo_apellido VARCHAR(100) NOT NULL,
    fecha_nacimiento DATE NOT NULL,
    telefono VARCHAR(20),
    semestre INT NOT NULL,
    carrera VARCHAR(10) NOT NULL,
    email VARCHAR(100) NOT NULL,
    contrasena VARCHAR(100) NOT NULL,
    tipo_tutoria VARCHAR(40) NOT NULL,
    maestro_id INT NOT NULL,
    FOREIGN KEY (maestro_id) REFERENCES Maestros(id)
);


INSERT INTO Maestros (nombre, genero) VALUES 
('Juan Pérez', 'hombre'),
('Ana López', 'mujer'),
('Carlos García', 'hombre'),
('María Rodríguez', 'mujer'),
('Luis Fernández', 'hombre'),
('Martha Patricia Jiménez Villanueva', 'mujer'),
('Patricia Escamilla Miranda', 'mujer'),
('Laura Méndez Segundo', 'mujer'),
('Laura Muñoz Salazar', 'mujer'),
('Judith Margarita Tirado Lule', 'mujer'),
('Karina Viveros Vela', 'mujer'),
('Rocio Palacios Solano', 'mujer'),
('Claudia Díaz Huerta', 'mujer'),
('Elia Ramírez Martínez', 'mujer'),
('Gabriela López Ruiz', 'mujer'),
('José Asunción Enríquez Zárate', 'hombre'),
('Alberto Jesús Alcántara Méndez', 'hombre'),
('Felipe de Jesús Figueroa del Prado', 'hombre'),
('Erick Linares Vallejo', 'hombre'),
('Edgar Armando Catalán', 'hombre'),
('Jorge Cortés Galicia', 'hombre'),
('Edgardo Franco Martínez', 'hombre'),
('Vicente García Sales', 'hombre'),
('Iván Mosso García', 'hombre'),
('Miguel Ángel Rodríguez', 'hombre');

INSERT INTO Alumnos (boleta, nombre, primer_apellido, segundo_apellido, fecha_nacimiento, telefono, semestre, carrera, email, contrasena, tipo_tutoria,maestro_id) VALUES
('20230001', 'Pedro', 'Martínez', 'Gómez', '2000-05-15', '5551234567', 3, 'ISC', 'pedro.martinez@alumno.ipn.mx', 'pass123','Individual',1),
('20230002', 'Laura', 'Sánchez', 'Díaz', '2001-08-22', '5559876543', 5, 'IIA', 'laura.sanchez@alumno.ipn.mx', 'pass123','Grupal',2),
('20230003', 'Miguel', 'Hernández', 'Torres', '1999-12-01', '5554567890', 7, 'LCD', 'miguel.hernandez@alumno.ipn.mx', 'pass123','Recuperación Académica',3),
('20230004', 'Lucía', 'Ramírez', 'Flores', '2002-03-17', '5552345678', 1, 'ISC', 'lucia.ramirez@alumno.ipn.mx', 'pass123','Regularización',4),
('20230006', 'Andrés', 'Gómez', 'Morales', '2000-11-11', '5558765432', 9, 'IIA', 'andres.gomez@alumno.ipn.mx', 'pass123','Entre Pares',5),
('20230007', 'Andrés', 'Gómez', 'Morales', '2000-11-11', '5558765432', 9, 'IIA', 'andres.gomez@alumno.ipn.mx', 'pass123','Entre Pares',5),
('20230008', 'Andrés', 'Gómez', 'Morales', '2000-11-11', '5558765432', 9, 'IIA', 'andres.gomez@alumno.ipn.mx', 'pass123','Entre Pares',5),
('20230009', 'Andrés', 'Gómez', 'Morales', '2000-11-11', '5558765432', 9, 'IIA', 'andres.gomez@alumno.ipn.mx', 'pass123','Entre Pares',5),
('20230010', 'Andrés', 'Gómez', 'Morales', '2000-11-11', '5558765432', 9, 'IIA', 'andres.gomez@alumno.ipn.mx', 'pass123','Entre Pares',5),
('20230011', 'Andrés', 'Gómez', 'Morales', '2000-11-11', '5558765432', 9, 'IIA', 'andres.gomez@alumno.ipn.mx', 'pass123','Entre Pares',5),
('20230012', 'Andrés', 'Gómez', 'Morales', '2000-11-11', '5558765432', 9, 'IIA', 'andres.gomez@alumno.ipn.mx', 'pass123','Entre Pares',5),
('20230013', 'Andrés', 'Gómez', 'Morales', '2000-11-11', '5558765432', 9, 'IIA', 'andres.gomez@alumno.ipn.mx', 'pass123','Entre Pares',5),
('20230014', 'Andrés', 'Gómez', 'Morales', '2000-11-11', '5558765432', 9, 'IIA', 'andres.gomez@alumno.ipn.mx', 'pass123','Entre Pares',5),
('20230015', 'Andrés', 'Gómez', 'Morales', '2000-11-11', '5558765432', 9, 'IIA', 'andres.gomez@alumno.ipn.mx', 'pass123','Entre Pares',5),
('20230016', 'Andrés', 'Gómez', 'Morales', '2000-11-11', '5558765432', 9, 'IIA', 'andres.gomez@alumno.ipn.mx', 'pass123','Entre Pares',5),
('20230170', 'Andrés', 'Gómez', 'Morales', '2000-11-11', '5558765432', 9, 'IIA', 'andres.gomez@alumno.ipn.mx', 'pass123','Entre Pares',5),
('20230018', 'Andrés', 'Gómez', 'Morales', '2000-11-11', '5558765432', 9, 'IIA', 'andres.gomez@alumno.ipn.mx', 'pass123','Entre Pares',5),
('20230019', 'Andrés', 'Gómez', 'Morales', '2000-11-11', '5558765432', 9, 'IIA', 'andres.gomez@alumno.ipn.mx', 'pass123','Entre Pares',5),
('20230020', 'Andrés', 'Gómez', 'Morales', '2000-11-11', '5558765432', 9, 'IIA', 'andres.gomez@alumno.ipn.mx', 'pass123','Entre Pares',5);

