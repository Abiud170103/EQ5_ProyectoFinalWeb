document.getElementById('formularioRegistro').addEventListener('submit', function(event) {
    // Previene el envío del formulario
    event.preventDefault();

    // Obtiene los valores de los campos
    let boleta = document.getElementById('boleta').value;
    let nombre = document.getElementById('nombre').value;
    let primerApe = document.getElementById('primerApe').value;
    let segundoApe = document.getElementById('segundoApe').value;
    let telefono = document.getElementById('telefono').value;
    let semestre = document.getElementById('semestre').value;
    let carrera = document.getElementById('carreraSelec').value;
    let preferenciaTutor = document.getElementById('preferenciaTutor').value;
    let email = document.getElementById('email').value;
    let contrasena = document.getElementById('contrasena').value;

    // Validaciones
    if (!esBoletaValida(boleta)) {
        alert('La boleta debe contener 10 dígitos numéricos.');
        return;
    }

    if (!esNombreValido(nombre)) {
        alert('El nombre solo puede contener letras.');
        return;
    }

    if (!esApellidoValido(primerApe)) {
        alert('El primer apellido solo puede contener letras.');
        return;
    }

    if (!esApellidoValido(segundoApe)) {
        alert('El segundo apellido solo puede contener letras.');
        return;
    }

    if (!esTelefonoValido(telefono)) {
        alert('El teléfono debe contener 10 dígitos numéricos.');
        return;
    }

    if (!esSemestreValido(semestre)) {
        alert('Selecciona un semestre válido.');
        return;
    }

    if (!esCarreraValida(carrera)) {
        alert('Selecciona una carrera.');
        return;
    }

    if (!esPreferenciaTutorValida(preferenciaTutor)) {
        alert('Selecciona una preferencia de tutor válida.');
        return;
    }

    if (!esEmailValido(email)) {
        alert('Introduce un correo electrónico válido.');
        return;
    }

    if (!esContrasenaValida(contrasena)) {
        alert('La contraseña debe tener al menos 6 caracteres.');
        return;
    }

    // Si todas las validaciones pasan, se puede enviar el formulario
    this.submit();
});

function esBoletaValida(boleta) {
    return /^\d{10}$/.test(boleta);
}

function esNombreValido(nombre) {
    return /^[A-Za-záéíóúÁÉÍÓÚñÑ\s]+$/.test(nombre);
}

function esApellidoValido(apellido) {
    return /^[A-Za-záéíóúÁÉÍÓÚñÑ\s]+$/.test(apellido);
}

function esTelefonoValido(telefono) {
    return /^\d{10}$/.test(telefono);
}

function esSemestreValido(semestre) {
    return /^[1-9]|10$/.test(semestre);
}

function esCarreraValida(carrera) {
    return carrera !== "";
}

function esPreferenciaTutorValida(preferencia) {
    return preferencia !== "";
}

function esEmailValido(email) {
    // Expresión regular que permite correos de dominios @ipn.mx y @alumno.ipn.mx
    // Permitiendo caracteres alfanuméricos, puntos, guiones bajos y combinaciones de mayúsculas y minúsculas
    return /^[a-zA-Z0-9._%+-]+@(ipn\.mx|alumno\.ipn\.mx)$/i.test(email);
}

function esContrasenaValida(contrasena) {
    return contrasena.length >= 6;
}

function limpiarFormulario() {
    document.getElementById('formularioRegistro').reset();
}

function mostrarMaestros() {
    var preferencia = document.getElementById('preferenciaTutor').value;

    var xhr = new XMLHttpRequest();
    xhr.open('GET', 'php/obt_maestros.php?preferenciaTutor=' + preferencia, true);
    xhr.onload = function() {
        if (this.status === 200) {
            var maestros = JSON.parse(this.responseText);
            var selectMaestro = document.getElementById('maestro');

            // Limpiar el select de maestros
            selectMaestro.innerHTML = '';

            // Agregar los maestros obtenidos al select
            maestros.forEach(function(maestro) {
                var option = document.createElement('option');
                option.value = maestro.nombre;  // Asegúrate de que `nombre` sea el valor correcto para `option.value`
                option.text = maestro.nombre;
                selectMaestro.appendChild(option);
            });
        }
    };
    xhr.send();
}