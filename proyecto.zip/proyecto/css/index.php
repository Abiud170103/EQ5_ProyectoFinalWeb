<?php
    header("location: ../inicio.html");
?>